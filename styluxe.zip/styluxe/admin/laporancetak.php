<html>
<title>LAPORAN</title>
<style type="text/css">
	body {
		-webkit-print-color-adjust: exact;
		padding: 50px;
	}

	#table {
		font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
		border-collapse: collapse;
	}

	#table td,
	#table th {
		padding: 8px;
		padding-top: 15px;
	}

	#table tr {
		padding-top: 15px;
		padding-bottom: 15px;
	}

	#table tr:nth-child(even) {
		background-color: #f2f2f2;
	}

	#table th {
		padding-top: 15px;
		padding-bottom: 15px;
		text-align: left;
		background-color: #4CAF50;
		color: white;
	}

	.biru {
		background-color: #06bbcc;
		color: white;
	}

	@page {
		size: auto;
		margin: 0;
	}
</style>
<?php
include('../koneksi.php');
if (isset($_GET['bulan']) && isset($_GET['tahun'])) {
	$bulan = $_GET['bulan'];
	$tahun = $_GET['tahun'];
	$tanggalawal = date('Y-m-01', strtotime("$tahun-$bulan-01"));
	$tanggalakhir = date('Y-m-t', strtotime("$tahun-$bulan-01"));
} else {
	$hariini = date('Y-m');
	$tanggalawal = date('Y-m-01', strtotime($hariini));
	$tanggalakhir = date('Y-m-t', strtotime($hariini));
}

function tanggal($tgl)
{
	$tanggal = substr($tgl, 8, 2);
	$bulan = getBulan(substr($tgl, 5, 2));
	$tahun = substr($tgl, 0, 4);
	return $tanggal . ' ' . $bulan . ' ' . $tahun;
}

function getBulan($bln)
{
	switch ($bln) {
		case 1:
			return "Januari";
		case 2:
			return "Februari";
		case 3:
			return "Maret";
		case 4:
			return "April";
		case 5:
			return "Mei";
		case 6:
			return "Juni";
		case 7:
			return "Juli";
		case 8:
			return "Agustus";
		case 9:
			return "September";
		case 10:
			return "Oktober";
		case 11:
			return "November";
		case 12:
			return "Desember";
	}
}
?>

	<body>
		<table width="470px">
			<tr>
				<td style="margin-right:50px"><img src="../foto/logo.jpg" width="125"></td>
				<td>
					<center>
						<font size="6"><b>Styluxe</b></font><br>
						<font size="3"><b>Mall Central Park</b></font><br>
					</center>
				</td>
			</tr>
		</table>
		<hr>
		<br>
		<center>
			<h4>
				<b>LAPORAN DATA</b>
				<br>
				<?= tanggal($tanggalawal) . ' - ' . tanggal($tanggalakhir) ?>
			</h4>
		</center>
		<br>
		<table class="tabel" id="table" width="100%">
			<thead class="bg-primary text-white">
				<tr>
					<th>No</th>
					<th>Nama</th>
					<th style="width: 150px;">No. HP</th>
					<th>Daftar</th>
					<th>Tanggal Pembelian</th>
					<th>Total Pembelian</th>
				</tr>
			</thead>
			<tbody>
				<?php
				$nomor = 1;
				$grandTotal = 0;
				$ambil = $koneksi->query("SELECT * FROM pembelian JOIN pengguna ON pembelian.id=pengguna.id WHERE tanggalbeli >= '$tanggalawal' AND tanggalbeli <= '$tanggalakhir' ORDER BY idpembelian DESC");
				while ($pecah = $ambil->fetch_assoc()) {
					$grandTotal += $pecah['totalbeli'];
					?>
					<tr>
						<td><?php echo $nomor; ?></td>
						<td><?php echo $pecah['nama'] ?></td>
						<td><?php echo ($pecah['telepon']) ?></a></td>
						<td>
							<ul>
								<?php
									$ambilproduk = $koneksi->query("SELECT * FROM pembelianproduk JOIN produk ON pembelianproduk.idproduk = produk.idproduk WHERE idpembelian='$pecah[idpembelian]'");
									while ($produk = $ambilproduk->fetch_assoc()) { ?>
									<li>
										<?= $produk['namaproduk'] ?>
										<br>
									</li>
								<?php } ?>
							</ul>
						</td>
						<td><?= tanggal(date('Y-m-d', strtotime($pecah['tanggalbeli']))) ?></td>
						<td>Rp. <?php echo number_format($pecah['totalbeli']) ?></td>
					</tr>
					<?php $nomor++; ?>
				<?php } ?>
				<tr>
					<td colspan="5" style="text-align:right;"><b>Grand Total:</b></td>
					<td><b>Rp. <?php echo number_format($grandTotal); ?></b></td>
				</tr>
			</tbody>
		</table>
	</body>
	<script>
		window.print();
	</script>

</html>