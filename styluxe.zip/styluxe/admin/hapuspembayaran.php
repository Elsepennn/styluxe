<?php
$koneksi->query("DELETE FROM pembelian WHERE idpembelian='$_GET[id]'");

echo "<script>alert('Data Berhasil Di Hapus');</script>";
echo "<script>location='index.php?halaman=pembelian';</script>";
